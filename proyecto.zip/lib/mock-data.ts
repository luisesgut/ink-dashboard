// ===== TIPOS =====

export type EstadoMaquina = "activa" | "parada" | "cambio"
export type SistemaTinta = "tradicional" | "colortrack"
export type EstadoSolicitud = "pendiente" | "fabricando" | "fabricado" | "entregado"
export type NivelUrgencia = "rojo" | "naranja" | "verde"

export interface Anilox {
  lineatura: number // LPI
  volumen: number // cm3/m2
}

export interface CuerpoImpresor {
  numero: number // 1-8
  color: string
  anilox: Anilox
  superficiePorcentaje: number
  serieTinta: string
  kgRestantes: number
}

export interface TrabajoActual {
  ordenProduccion: string
  producto: string
  metrosTotales: number
  metrosRestantes: number
  velocidadActual: number // metros/min
  anchoImpresion: number // metros
}

export interface Impresora {
  id: string
  nombre: string
  estado: EstadoMaquina
  sistema: SistemaTinta
  trabajoActual: TrabajoActual | null
  cuerpos: CuerpoImpresor[]
  solicitudesPendientes: number
  tieneNotificacion: boolean
}

export interface SolicitudTinta {
  id: string
  timestamp: Date
  impresoraId: string
  impresoraNombre: string
  cuerpoNumero: number
  color: string
  serieTinta: string
  kgEnMaquina: number
  metrosRestantes: number
  superficiePorcentaje: number
  aniloxLineatura: number
  aniloxVolumen: number
  velocidadActual: number
  viscosidadActual: number
  anchoImpresion: number
  // Campos calculados
  kgAFabricar: number
  tiempoEstimadoMin: number
  urgencia: NivelUrgencia
  // Estado
  estado: EstadoSolicitud
  kgFabricados?: number
  timestampFabricando?: Date
  timestampFabricado?: Date
  timestampEntregado?: Date
}

export interface Notificacion {
  id: string
  impresoraId: string
  impresoraNombre: string
  solicitudId: string
  color: string
  tipo: "fabricando" | "fabricado"
  mensaje: string
  timestamp: Date
  leida: boolean
}

export interface RegistroHistorial {
  id: string
  fechaSolicitud: Date
  fechaCompletado: Date
  impresoraNombre: string
  color: string
  serieTinta: string
  kgSolicitados: number
  kgFabricados: number
  tiempoUrgenciaOriginal: number
  tiempoRealFabricacion: number // minutos
  estado: "completado" | "retorno_parcial"
}

// ===== FUNCIONES DE CALCULO =====

export function calcularKgNecesarios(
  metrosRestantes: number,
  superficiePorcentaje: number,
  aniloxVolumen: number,
  anchoImpresion: number,
  kgEnMaquina: number
): number {
  const consumoPorMetro = (superficiePorcentaje / 100) * (aniloxVolumen / 1000) * anchoImpresion
  const kgNecesarios = Math.max(0, metrosRestantes * consumoPorMetro - kgEnMaquina)
  return Math.round(kgNecesarios * 10) / 10
}

export function calcularTiempoMinutos(metrosRestantes: number, velocidadActual: number): number {
  if (velocidadActual <= 0) return 999
  return Math.round(metrosRestantes / velocidadActual)
}

export function determinarUrgencia(tiempoMinutos: number): NivelUrgencia {
  if (tiempoMinutos <= 30) return "rojo"
  if (tiempoMinutos <= 40) return "naranja"
  return "verde"
}

export function getUrgenciaLabel(urgencia: NivelUrgencia): string {
  switch (urgencia) {
    case "rojo": return "Urgente"
    case "naranja": return "Moderado"
    case "verde": return "Normal"
  }
}

export function getEstadoLabel(estado: EstadoSolicitud): string {
  switch (estado) {
    case "pendiente": return "En Espera"
    case "fabricando": return "Fabricando"
    case "fabricado": return "Fabricado"
    case "entregado": return "Entregado"
  }
}

// ===== DATOS MOCK =====

const colores = [
  "Blanco", "Negro", "Cyan", "Magenta", "Amarillo", "Rojo 485C",
  "Verde 356C", "Azul 2728C", "Naranja 021C", "Dorado 871C",
  "Pantone 186C", "Pantone 289C"
]

const seriesTinta = [
  "FLEXO-WB-100", "FLEXO-WB-200", "FLEXO-SV-300", "FLEXO-UV-400",
  "FLEXO-WB-150", "FLEXO-SV-250", "FLEXO-WB-350", "FLEXO-UV-450"
]

function crearCuerpos(): CuerpoImpresor[] {
  return Array.from({ length: 8 }, (_, i) => ({
    numero: i + 1,
    color: colores[i % colores.length],
    anilox: {
      lineatura: [300, 360, 400, 500, 600, 700, 800, 900][i % 8],
      volumen: [3.5, 4.0, 5.0, 6.5, 7.0, 8.0, 10.0, 12.0][i % 8],
    },
    superficiePorcentaje: [15, 25, 40, 60, 80, 35, 50, 20][i % 8],
    serieTinta: seriesTinta[i % seriesTinta.length],
    kgRestantes: [2.5, 8.0, 1.2, 15.0, 5.5, 3.0, 10.0, 6.0][i % 8],
  }))
}

export const impresoras: Impresora[] = [
  {
    id: "bobst-01",
    nombre: "Bobst 01",
    estado: "activa",
    sistema: "tradicional",
    trabajoActual: {
      ordenProduccion: "OP-2026-001",
      producto: "Bolsa Pan Bimbo 500g",
      metrosTotales: 15000,
      metrosRestantes: 4200,
      velocidadActual: 180,
      anchoImpresion: 1.2,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 2,
    tieneNotificacion: true,
  },
  {
    id: "bobst-02",
    nombre: "Bobst 02",
    estado: "activa",
    sistema: "colortrack",
    trabajoActual: {
      ordenProduccion: "OP-2026-002",
      producto: "Empaque Sabritas Original",
      metrosTotales: 22000,
      metrosRestantes: 8500,
      velocidadActual: 200,
      anchoImpresion: 1.0,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 1,
    tieneNotificacion: false,
  },
  {
    id: "bobst-03",
    nombre: "Bobst 03",
    estado: "activa",
    sistema: "tradicional",
    trabajoActual: {
      ordenProduccion: "OP-2026-003",
      producto: "Etiqueta Coca-Cola 600ml",
      metrosTotales: 30000,
      metrosRestantes: 12000,
      velocidadActual: 250,
      anchoImpresion: 0.8,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 0,
    tieneNotificacion: false,
  },
  {
    id: "bobst-04",
    nombre: "Bobst 04",
    estado: "cambio",
    sistema: "colortrack",
    trabajoActual: null,
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 0,
    tieneNotificacion: false,
  },
  {
    id: "bobst-05",
    nombre: "Bobst 05",
    estado: "activa",
    sistema: "tradicional",
    trabajoActual: {
      ordenProduccion: "OP-2026-005",
      producto: "Bolsa Doritos Nacho",
      metrosTotales: 18000,
      metrosRestantes: 3500,
      velocidadActual: 160,
      anchoImpresion: 1.1,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 3,
    tieneNotificacion: true,
  },
  {
    id: "bobst-06",
    nombre: "Bobst 06",
    estado: "parada",
    sistema: "tradicional",
    trabajoActual: {
      ordenProduccion: "OP-2026-006",
      producto: "Envoltura Chocolate Abuelita",
      metrosTotales: 10000,
      metrosRestantes: 800,
      velocidadActual: 0,
      anchoImpresion: 0.9,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 1,
    tieneNotificacion: true,
  },
  {
    id: "bobst-07",
    nombre: "Bobst 07",
    estado: "activa",
    sistema: "colortrack",
    trabajoActual: {
      ordenProduccion: "OP-2026-007",
      producto: "Bolsa Cafe Legal 250g",
      metrosTotales: 25000,
      metrosRestantes: 18000,
      velocidadActual: 220,
      anchoImpresion: 1.3,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 0,
    tieneNotificacion: false,
  },
  {
    id: "bobst-08",
    nombre: "Bobst 08",
    estado: "activa",
    sistema: "tradicional",
    trabajoActual: {
      ordenProduccion: "OP-2026-008",
      producto: "Etiqueta Modelo Especial",
      metrosTotales: 20000,
      metrosRestantes: 6000,
      velocidadActual: 190,
      anchoImpresion: 1.0,
    },
    cuerpos: crearCuerpos(),
    solicitudesPendientes: 0,
    tieneNotificacion: false,
  },
]

const ahora = new Date()
function horasAtras(h: number): Date {
  return new Date(ahora.getTime() - h * 60 * 60 * 1000)
}
function minutosAtras(m: number): Date {
  return new Date(ahora.getTime() - m * 60 * 1000)
}

export const solicitudes: SolicitudTinta[] = [
  {
    id: "SOL-001",
    timestamp: minutosAtras(5),
    impresoraId: "bobst-01",
    impresoraNombre: "Bobst 01",
    cuerpoNumero: 3,
    color: "Cyan",
    serieTinta: "FLEXO-WB-200",
    kgEnMaquina: 1.2,
    metrosRestantes: 4200,
    superficiePorcentaje: 40,
    aniloxLineatura: 400,
    aniloxVolumen: 5.0,
    velocidadActual: 180,
    viscosidadActual: 22,
    anchoImpresion: 1.2,
    kgAFabricar: 8.9,
    tiempoEstimadoMin: 23,
    urgencia: "rojo",
    estado: "pendiente",
  },
  {
    id: "SOL-002",
    timestamp: minutosAtras(12),
    impresoraId: "bobst-01",
    impresoraNombre: "Bobst 01",
    cuerpoNumero: 5,
    color: "Amarillo",
    serieTinta: "FLEXO-WB-150",
    kgEnMaquina: 5.5,
    metrosRestantes: 4200,
    superficiePorcentaje: 80,
    aniloxLineatura: 600,
    aniloxVolumen: 7.0,
    velocidadActual: 180,
    viscosidadActual: 24,
    anchoImpresion: 1.2,
    kgAFabricar: 22.7,
    tiempoEstimadoMin: 23,
    urgencia: "rojo",
    estado: "fabricando",
    timestampFabricando: minutosAtras(8),
  },
  {
    id: "SOL-003",
    timestamp: minutosAtras(25),
    impresoraId: "bobst-02",
    impresoraNombre: "Bobst 02",
    cuerpoNumero: 1,
    color: "Blanco",
    serieTinta: "FLEXO-WB-100",
    kgEnMaquina: 2.5,
    metrosRestantes: 8500,
    superficiePorcentaje: 15,
    aniloxLineatura: 300,
    aniloxVolumen: 3.5,
    velocidadActual: 200,
    viscosidadActual: 20,
    anchoImpresion: 1.0,
    kgAFabricar: 2.0,
    tiempoEstimadoMin: 42,
    urgencia: "verde",
    estado: "fabricado",
    timestampFabricando: minutosAtras(20),
    timestampFabricado: minutosAtras(10),
    kgFabricados: 2.5,
  },
  {
    id: "SOL-004",
    timestamp: minutosAtras(8),
    impresoraId: "bobst-05",
    impresoraNombre: "Bobst 05",
    cuerpoNumero: 4,
    color: "Magenta",
    serieTinta: "FLEXO-SV-300",
    kgEnMaquina: 3.0,
    metrosRestantes: 3500,
    superficiePorcentaje: 60,
    aniloxLineatura: 500,
    aniloxVolumen: 6.5,
    velocidadActual: 160,
    viscosidadActual: 21,
    anchoImpresion: 1.1,
    kgAFabricar: 11.2,
    tiempoEstimadoMin: 22,
    urgencia: "rojo",
    estado: "pendiente",
  },
  {
    id: "SOL-005",
    timestamp: minutosAtras(15),
    impresoraId: "bobst-05",
    impresoraNombre: "Bobst 05",
    cuerpoNumero: 2,
    color: "Negro",
    serieTinta: "FLEXO-WB-200",
    kgEnMaquina: 8.0,
    metrosRestantes: 3500,
    superficiePorcentaje: 25,
    aniloxLineatura: 360,
    aniloxVolumen: 4.0,
    velocidadActual: 160,
    viscosidadActual: 23,
    anchoImpresion: 1.1,
    kgAFabricar: 0,
    tiempoEstimadoMin: 22,
    urgencia: "rojo",
    estado: "fabricando",
    timestampFabricando: minutosAtras(10),
  },
  {
    id: "SOL-006",
    timestamp: minutosAtras(40),
    impresoraId: "bobst-05",
    impresoraNombre: "Bobst 05",
    cuerpoNumero: 6,
    color: "Verde 356C",
    serieTinta: "FLEXO-SV-250",
    kgEnMaquina: 3.0,
    metrosRestantes: 5800,
    superficiePorcentaje: 35,
    aniloxLineatura: 700,
    aniloxVolumen: 8.0,
    velocidadActual: 160,
    viscosidadActual: 22,
    anchoImpresion: 1.1,
    kgAFabricar: 15.0,
    tiempoEstimadoMin: 36,
    urgencia: "naranja",
    estado: "fabricado",
    timestampFabricando: minutosAtras(30),
    timestampFabricado: minutosAtras(18),
    kgFabricados: 16.0,
  },
  {
    id: "SOL-007",
    timestamp: minutosAtras(50),
    impresoraId: "bobst-06",
    impresoraNombre: "Bobst 06",
    cuerpoNumero: 1,
    color: "Rojo 485C",
    serieTinta: "FLEXO-WB-100",
    kgEnMaquina: 0.5,
    metrosRestantes: 800,
    superficiePorcentaje: 15,
    aniloxLineatura: 300,
    aniloxVolumen: 3.5,
    velocidadActual: 0,
    viscosidadActual: 19,
    anchoImpresion: 0.9,
    kgAFabricar: 0,
    tiempoEstimadoMin: 999,
    urgencia: "verde",
    estado: "pendiente",
  },
]

export const notificaciones: Notificacion[] = [
  {
    id: "NOT-001",
    impresoraId: "bobst-01",
    impresoraNombre: "Bobst 01",
    solicitudId: "SOL-002",
    color: "Amarillo",
    tipo: "fabricando",
    mensaje: "Su tinta Amarillo se esta fabricando",
    timestamp: minutosAtras(8),
    leida: false,
  },
  {
    id: "NOT-002",
    impresoraId: "bobst-02",
    impresoraNombre: "Bobst 02",
    solicitudId: "SOL-003",
    color: "Blanco",
    tipo: "fabricado",
    mensaje: "Tinta Blanco lista - Confirmar recepcion",
    timestamp: minutosAtras(10),
    leida: false,
  },
  {
    id: "NOT-003",
    impresoraId: "bobst-05",
    impresoraNombre: "Bobst 05",
    solicitudId: "SOL-005",
    color: "Negro",
    tipo: "fabricando",
    mensaje: "Su tinta Negro se esta fabricando",
    timestamp: minutosAtras(10),
    leida: false,
  },
  {
    id: "NOT-004",
    impresoraId: "bobst-05",
    impresoraNombre: "Bobst 05",
    solicitudId: "SOL-006",
    color: "Verde 356C",
    tipo: "fabricado",
    mensaje: "Tinta Verde 356C lista - Confirmar recepcion",
    timestamp: minutosAtras(18),
    leida: false,
  },
  {
    id: "NOT-005",
    impresoraId: "bobst-06",
    impresoraNombre: "Bobst 06",
    solicitudId: "SOL-007",
    color: "Rojo 485C",
    tipo: "fabricando",
    mensaje: "Su tinta Rojo 485C se esta fabricando",
    timestamp: minutosAtras(45),
    leida: true,
  },
]

export const historial: RegistroHistorial[] = [
  {
    id: "HIS-001",
    fechaSolicitud: horasAtras(8),
    fechaCompletado: horasAtras(7.5),
    impresoraNombre: "Bobst 01",
    color: "Blanco",
    serieTinta: "FLEXO-WB-100",
    kgSolicitados: 12.5,
    kgFabricados: 13.0,
    tiempoUrgenciaOriginal: 25,
    tiempoRealFabricacion: 18,
    estado: "completado",
  },
  {
    id: "HIS-002",
    fechaSolicitud: horasAtras(7),
    fechaCompletado: horasAtras(6.5),
    impresoraNombre: "Bobst 03",
    color: "Cyan",
    serieTinta: "FLEXO-WB-200",
    kgSolicitados: 8.0,
    kgFabricados: 10.0,
    tiempoUrgenciaOriginal: 35,
    tiempoRealFabricacion: 22,
    estado: "retorno_parcial",
  },
  {
    id: "HIS-003",
    fechaSolicitud: horasAtras(6),
    fechaCompletado: horasAtras(5.8),
    impresoraNombre: "Bobst 02",
    color: "Magenta",
    serieTinta: "FLEXO-SV-300",
    kgSolicitados: 5.2,
    kgFabricados: 5.2,
    tiempoUrgenciaOriginal: 42,
    tiempoRealFabricacion: 15,
    estado: "completado",
  },
  {
    id: "HIS-004",
    fechaSolicitud: horasAtras(5),
    fechaCompletado: horasAtras(4.5),
    impresoraNombre: "Bobst 07",
    color: "Negro",
    serieTinta: "FLEXO-WB-200",
    kgSolicitados: 18.0,
    kgFabricados: 20.0,
    tiempoUrgenciaOriginal: 28,
    tiempoRealFabricacion: 25,
    estado: "retorno_parcial",
  },
  {
    id: "HIS-005",
    fechaSolicitud: horasAtras(4),
    fechaCompletado: horasAtras(3.7),
    impresoraNombre: "Bobst 05",
    color: "Amarillo",
    serieTinta: "FLEXO-WB-150",
    kgSolicitados: 9.8,
    kgFabricados: 10.0,
    tiempoUrgenciaOriginal: 32,
    tiempoRealFabricacion: 20,
    estado: "completado",
  },
  {
    id: "HIS-006",
    fechaSolicitud: horasAtras(3.5),
    fechaCompletado: horasAtras(3),
    impresoraNombre: "Bobst 08",
    color: "Rojo 485C",
    serieTinta: "FLEXO-WB-100",
    kgSolicitados: 6.5,
    kgFabricados: 6.5,
    tiempoUrgenciaOriginal: 45,
    tiempoRealFabricacion: 12,
    estado: "completado",
  },
  {
    id: "HIS-007",
    fechaSolicitud: horasAtras(3),
    fechaCompletado: horasAtras(2.5),
    impresoraNombre: "Bobst 01",
    color: "Verde 356C",
    serieTinta: "FLEXO-SV-250",
    kgSolicitados: 14.0,
    kgFabricados: 15.5,
    tiempoUrgenciaOriginal: 20,
    tiempoRealFabricacion: 28,
    estado: "retorno_parcial",
  },
  {
    id: "HIS-008",
    fechaSolicitud: horasAtras(2),
    fechaCompletado: horasAtras(1.8),
    impresoraNombre: "Bobst 04",
    color: "Azul 2728C",
    serieTinta: "FLEXO-SV-300",
    kgSolicitados: 7.3,
    kgFabricados: 7.5,
    tiempoUrgenciaOriginal: 38,
    tiempoRealFabricacion: 16,
    estado: "completado",
  },
  {
    id: "HIS-009",
    fechaSolicitud: horasAtras(1.5),
    fechaCompletado: horasAtras(1.2),
    impresoraNombre: "Bobst 03",
    color: "Blanco",
    serieTinta: "FLEXO-WB-100",
    kgSolicitados: 22.0,
    kgFabricados: 22.0,
    tiempoUrgenciaOriginal: 55,
    tiempoRealFabricacion: 30,
    estado: "completado",
  },
  {
    id: "HIS-010",
    fechaSolicitud: horasAtras(1),
    fechaCompletado: horasAtras(0.7),
    impresoraNombre: "Bobst 06",
    color: "Naranja 021C",
    serieTinta: "FLEXO-UV-400",
    kgSolicitados: 4.0,
    kgFabricados: 5.0,
    tiempoUrgenciaOriginal: 18,
    tiempoRealFabricacion: 14,
    estado: "retorno_parcial",
  },
]

// Datos para graficos
export const consumoPorMaquina = [
  { maquina: "Bobst 01", kg: 48.5 },
  { maquina: "Bobst 02", kg: 32.0 },
  { maquina: "Bobst 03", kg: 55.2 },
  { maquina: "Bobst 04", kg: 18.0 },
  { maquina: "Bobst 05", kg: 42.8 },
  { maquina: "Bobst 06", kg: 15.5 },
  { maquina: "Bobst 07", kg: 28.0 },
  { maquina: "Bobst 08", kg: 22.3 },
]

export const tiemposRespuesta = [
  { hora: "06:00", minutos: 15 },
  { hora: "07:00", minutos: 12 },
  { hora: "08:00", minutos: 22 },
  { hora: "09:00", minutos: 18 },
  { hora: "10:00", minutos: 25 },
  { hora: "11:00", minutos: 14 },
  { hora: "12:00", minutos: 30 },
  { hora: "13:00", minutos: 20 },
  { hora: "14:00", minutos: 16 },
]
