import type { Impresora, TrabajoActual } from "@/lib/mock-data"
import type { TintasDTO } from "@/lib/tablero-hub"

function parseNumber(value: string): number | null {
  const normalized = value.replace(/,/g, "")
  const parsed = Number(normalized)
  return Number.isFinite(parsed) ? parsed : null
}

export function parseCantidadPorUnidad(
  value: string,
  unit: "KGM" | "MTR"
): number | null {
  const regex = new RegExp(`([\\d.,]+)\\s*${unit}`, "i")
  const match = value.match(regex)
  if (!match?.[1]) return null
  return parseNumber(match[1])
}

export function prensaToMachineId(prensa: string): string {
  const onlyDigits = prensa.replace(/\D/g, "")
  const normalized = onlyDigits.padStart(2, "0")
  return `bobst-${normalized}`
}

export function machineIdToPrensa(machineId: string): string | null {
  const match = machineId.match(/(\d{1,2})$/)
  if (!match?.[1]) return null
  return match[1].padStart(2, "0")
}

export function tintasToImpresoras(rows: TintasDTO[]): Impresora[] {
  const grouped = rows.reduce<Record<string, TintasDTO[]>>((acc, row) => {
    const prensa = row.prensa.replace(/\D/g, "").padStart(2, "0")
    if (!acc[prensa]) acc[prensa] = []
    acc[prensa].push(row)
    return acc
  }, {})

  return Object.entries(grouped)
    .map(([prensa, trabajos]) => {
      const row = trabajos[0]
      const metrosTotales = parseCantidadPorUnidad(row.cantidadSolicitada, "MTR") ?? 0
      const metrosRestantes = parseCantidadPorUnidad(row.cantidadFaltante, "MTR") ?? 0
      const porcentaje = Number.isFinite(row.porcentaje) ? row.porcentaje : 0

      const trabajoActual: TrabajoActual = {
        ordenProduccion: row.orden,
        producto: row.producto,
        metrosTotales: metrosTotales > 0 ? metrosTotales : Math.max(metrosRestantes, 1),
        metrosRestantes,
        velocidadActual: 0,
        anchoImpresion: 0,
      }

      return {
        id: prensaToMachineId(prensa),
        nombre: `Prensa ${prensa}`,
        estado: porcentaje >= 100 ? "cambio" : "activa",
        sistema: "tradicional",
        trabajoActual,
        cuerpos: [],
        solicitudesPendientes: trabajos.length,
        tieneNotificacion: false,
      } satisfies Impresora
    })
    .sort((a, b) => a.nombre.localeCompare(b.nombre))
}
