"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import { useInkStore } from "@/lib/store"
import { useTableroHub } from "@/lib/tablero-hub"
import {
  machineIdToPrensa,
  parseCantidadPorUnidad,
} from "@/lib/tablero-mappers"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { StatusBadge } from "@/components/status-badge"
import { FlashingAlert } from "@/components/flashing-alert"
import { UrgencyBadge } from "@/components/urgency-badge"
import {
  ArrowLeft,
  Droplets,
  Gauge,
  Ruler,
  Printer,
} from "lucide-react"

const colorMap: Record<string, string> = {
  Blanco: "#f5f5f5",
  Negro: "#1a1a1a",
  Cyan: "#00bcd4",
  Magenta: "#e91e63",
  Amarillo: "#ffeb3b",
  "Rojo 485C": "#f44336",
  "Verde 356C": "#4caf50",
  "Azul 2728C": "#2196f3",
  "Naranja 021C": "#ff9800",
  "Dorado 871C": "#ffd700",
  "Pantone 186C": "#ce1126",
  "Pantone 289C": "#0c2340",
}

function getColorHex(colorName: string): string {
  return colorMap[colorName] || "#9e9e9e"
}

export default function MaquinaPage() {
  const params = useParams()
  const id = params.id as string
  const { impresoras, getSolicitudesPorMaquina, getNotificacionesPorMaquina, confirmarRecepcion } = useInkStore()
  const normalizedMachineId = /^\d{1,2}$/.test(id) ? `bobst-${id.padStart(2, "0")}` : id
  const prensa = machineIdToPrensa(normalizedMachineId) ?? machineIdToPrensa(id)
  const { datos: datosTablero, connectionState, error } = useTableroHub(prensa ?? undefined)
  const impresora = impresoras.find((i) => i.id === normalizedMachineId)

  const solicitudesMaquina = getSolicitudesPorMaquina(normalizedMachineId).filter(
    (s) => s.estado !== "entregado"
  )
  const notificacionesMaquina = getNotificacionesPorMaquina(normalizedMachineId).filter(
    (n) => !n.leida
  )

  const tableroActual = datosTablero[0]
  const trabajoActual = impresora?.trabajoActual ?? null
  const estadoActual = impresora?.estado ?? (tableroActual && tableroActual.porcentaje >= 100 ? "cambio" : "activa")
  const nombreActual = tableroActual ? `Prensa ${tableroActual.prensa}` : impresora?.nombre ?? `Prensa ${prensa ?? id}`
  const sistemaActual = impresora?.sistema ?? "tradicional"

  if (!impresora && !tableroActual) {
    return (
      <div className="flex items-center justify-center py-20">
        <p className="text-muted-foreground">Impresora no encontrada</p>
      </div>
    )
  }

  const metrosRestantesHub = tableroActual
    ? parseCantidadPorUnidad(tableroActual.cantidadFaltante, "MTR")
    : null
  const metrosTotalesHub = tableroActual
    ? parseCantidadPorUnidad(tableroActual.cantidadSolicitada, "MTR")
    : null
  const progreso = tableroActual
    ? tableroActual.porcentaje
    : trabajoActual
    ? Math.round(
        ((trabajoActual.metrosTotales - trabajoActual.metrosRestantes) /
          trabajoActual.metrosTotales) *
          100
      )
    : 0

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon" className="shrink-0">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-bold text-foreground">
                {nombreActual}
              </h2>
              <Badge
                variant="outline"
                className={
                  estadoActual === "activa"
                    ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                    : estadoActual === "parada"
                    ? "bg-red-100 text-red-800 border-red-300"
                    : "bg-amber-100 text-amber-800 border-amber-300"
                }
              >
                {estadoActual === "activa"
                  ? "Activa"
                  : estadoActual === "parada"
                  ? "Parada"
                  : "Cambio"}
              </Badge>
              <Badge variant="secondary" className="uppercase text-[10px]">
                {sistemaActual}
              </Badge>
            </div>
            {(trabajoActual || tableroActual) && (
              <p className="text-sm text-muted-foreground">
                {tableroActual
                  ? `${tableroActual.orden} - ${tableroActual.producto}`
                  : `${trabajoActual?.ordenProduccion ?? ""} - ${trabajoActual?.producto ?? ""}`}
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Hub: {connectionState}
              {error ? ` - ${error}` : ""}
            </p>
          </div>
        </div>
      </div>

      {/* Job info */}
      {(trabajoActual || tableroActual) && (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Progreso
              </CardTitle>
              <Printer className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="mb-2 text-2xl font-bold font-mono text-foreground">
                {progreso}%
              </div>
              <Progress value={progreso} className="h-2" />
              <p className="mt-1 text-xs text-muted-foreground">
                {metrosRestantesHub ?? trabajoActual?.metrosRestantes ?? 0}m restantes
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Metros Totales
              </CardTitle>
              <Ruler className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {metrosTotalesHub ?? trabajoActual?.metrosTotales ?? 0}
              </div>
              <p className="text-xs text-muted-foreground">metros lineales</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Velocidad Actual
              </CardTitle>
              <Gauge className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {trabajoActual?.velocidadActual ?? 0}
              </div>
              <p className="text-xs text-muted-foreground">metros/min</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Ancho Impresion
              </CardTitle>
              <Droplets className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold font-mono text-foreground">
                {trabajoActual?.anchoImpresion ?? 0}
              </div>
              <p className="text-xs text-muted-foreground">metros</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Notificaciones activas */}
      {notificacionesMaquina.length > 0 && (
        <div>
          <h3 className="mb-3 text-lg font-semibold text-foreground">
            Notificaciones Activas
          </h3>
          <div className="flex flex-col gap-2">
            {notificacionesMaquina.map((n) => (
              <div key={n.id} className="flex items-center gap-2">
                <div className="flex-1">
                  <FlashingAlert
                    tipo={n.tipo}
                    mensaje={n.mensaje}
                    timestamp={n.timestamp}
                    leida={n.leida}
                  />
                </div>
                {n.tipo === "fabricado" && (
                  <Button
                    size="sm"
                    onClick={() => confirmarRecepcion(n.solicitudId)}
                  >
                    Confirmar
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Solicitudes activas */}
      {solicitudesMaquina.length > 0 && (
        <div>
          <h3 className="mb-3 text-lg font-semibold text-foreground">
            Solicitudes de Tinta Activas
          </h3>
          <div className="flex flex-col gap-2">
            {solicitudesMaquina.map((s) => (
              <Card key={s.id} className="p-4">
                <div className="flex flex-wrap items-center gap-4">
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {s.id} - Cuerpo {s.cuerpoNumero}
                    </p>
                    <p className="text-xs text-muted-foreground">{s.color} ({s.serieTinta})</p>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Kg: </span>
                    <span className="font-mono font-semibold text-foreground">{s.kgAFabricar}</span>
                  </div>
                  <UrgencyBadge urgencia={s.urgencia} tiempoMin={s.tiempoEstimadoMin} />
                  <StatusBadge estado={s.estado} />
                  {s.estado === "fabricado" && (
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => confirmarRecepcion(s.id)}
                    >
                      Confirmar Recepcion
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Cuerpos Impresores Table */}
      <div>
        <h3 className="mb-3 text-lg font-semibold text-foreground">
          Cuerpos Impresores
        </h3>
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">#</TableHead>
                  <TableHead>Color</TableHead>
                  <TableHead>Anilox (LPI)</TableHead>
                  <TableHead>Volumen</TableHead>
                  <TableHead>Superficie %</TableHead>
                  <TableHead>Serie Tinta</TableHead>
                  <TableHead>Kg Restantes</TableHead>
                  <TableHead className="text-right">Accion</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {(impresora?.cuerpos ?? []).map((cuerpo) => (
                  <TableRow key={cuerpo.numero}>
                    <TableCell className="font-mono font-bold text-foreground">
                      {cuerpo.numero}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div
                          className="h-4 w-4 rounded-full border border-border"
                          style={{ backgroundColor: getColorHex(cuerpo.color) }}
                        />
                        <span className="font-medium text-foreground">{cuerpo.color}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-foreground">
                      {cuerpo.anilox.lineatura}
                    </TableCell>
                    <TableCell className="font-mono text-foreground">
                      {cuerpo.anilox.volumen} cm3/m2
                    </TableCell>
                    <TableCell className="font-mono text-foreground">{cuerpo.superficiePorcentaje}%</TableCell>
                    <TableCell className="text-xs text-muted-foreground">
                      {cuerpo.serieTinta}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`font-mono font-bold ${
                          cuerpo.kgRestantes < 3
                            ? "text-urgency-red"
                            : cuerpo.kgRestantes < 6
                            ? "text-urgency-orange"
                            : "text-foreground"
                        }`}
                      >
                        {cuerpo.kgRestantes} kg
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      <Link
                        href={`/maquina/${id}/solicitud?cuerpo=${cuerpo.numero}`}
                      >
                        <Button size="sm" variant="default">
                          <Droplets className="mr-1 h-3 w-3" />
                          Solicitar Tinta
                        </Button>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  )
}
