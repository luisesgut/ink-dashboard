"use client"

import { useMemo } from "react"
import { useInkStore } from "@/lib/store"
import { PrinterCard } from "@/components/printer-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTableroHub } from "@/lib/tablero-hub"
import { tintasToImpresoras } from "@/lib/tablero-mappers"
import {
  Printer,
  AlertTriangle,
  FlaskConical,
  Clock,
} from "lucide-react"

export default function DashboardPage() {
  const { impresoras, solicitudes } = useInkStore()
  const { datos: datosTablero, connectionState, error } = useTableroHub()

  const impresorasHub = useMemo(() => tintasToImpresoras(datosTablero), [datosTablero])
  const usandoHub = impresorasHub.length > 0
  const impresorasRender = usandoHub ? impresorasHub : impresoras

  const maquinasActivas = impresorasRender.filter((i) => i.estado === "activa").length
  const solicitudesPendientes = usandoHub
    ? datosTablero.length
    : solicitudes.filter((s) => s.estado === "pendiente").length
  const solicitudesUrgentes = usandoHub
    ? datosTablero.filter((s) => s.porcentaje >= 80 && s.porcentaje < 100).length
    : solicitudes.filter((s) => s.urgencia === "rojo" && s.estado !== "entregado").length
  const enFabricacion = usandoHub
    ? datosTablero.filter((s) => s.porcentaje > 0 && s.porcentaje < 100).length
    : solicitudes.filter((s) => s.estado === "fabricando").length

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground text-balance">
          Panel de Control
        </h2>
        <p className="text-sm text-muted-foreground">
          Estado en tiempo real de las impresoras y solicitudes de tinta
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Fuente: {usandoHub ? "tableroImpresionHub" : "mock local"} ({connectionState})
          {error ? ` - ${error}` : ""}
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Maquinas Activas
            </CardTitle>
            <Printer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{maquinasActivas}</div>
            <p className="text-xs text-muted-foreground">de {impresorasRender.length} totales</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Solicitudes Pendientes
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{solicitudesPendientes}</div>
            <p className="text-xs text-muted-foreground">esperando fabricacion</p>
          </CardContent>
        </Card>

        <Card className="border-urgency-red/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-urgency-red">
              Urgentes
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-urgency-red" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-urgency-red font-mono">{solicitudesUrgentes}</div>
            <p className="text-xs text-muted-foreground">{"menos de 30 min"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              En Fabricacion
            </CardTitle>
            <FlaskConical className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{enFabricacion}</div>
            <p className="text-xs text-muted-foreground">tinta en proceso</p>
          </CardContent>
        </Card>
      </div>

      {/* Printer Grid */}
      <div>
        <h3 className="mb-4 text-lg font-semibold text-foreground">
          Impresoras
        </h3>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {impresorasRender.map((impresora) => (
            <PrinterCard key={impresora.id} impresora={impresora} />
          ))}
        </div>
      </div>
    </div>
  )
}
