"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { useInkStore } from "@/lib/store"
import { useTableroHub } from "@/lib/tablero-hub"
import { machineIdToPrensa, normalizePrensaCode, parseCantidadPorUnidad } from "@/lib/tablero-mappers"
import { calcularTiempoMinutos, determinarUrgencia } from "@/lib/mock-data"
import { getPrintCard, getTinta, calcularKgPorColor, type KgPorColor } from "@/lib/pocketbase"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import { StatusBadge } from "@/components/status-badge"
import { FlashingAlert } from "@/components/flashing-alert"
import { UrgencyBadge } from "@/components/urgency-badge"
import {
  ArrowLeft, Droplets, Gauge, LoaderCircle, Ruler, Printer, Send
} from "lucide-react"
import { toast } from "sonner"

const KG_BASE_MAQUINA: Record<string, number> = {
  "I01-BOBST 1": 20, "I02-BOBST 2": 20, "I03-VISION 4": 10,
  "I04-VISION 3": 10, "I05-VISION 2": 10, "I06-BOBST 3": 20,
  "I07-VISION 1": 10, "I08-SCHIAVI": 20,
}

// Estado editable por fila de color
interface FilaColor extends KgPorColor {
  kgEnMaquina: string   // lo ingresa el operador
  viscosidad: string    // lo ingresa el operador
  enviando: boolean
}

export default function MaquinaPage() {
  const params = useParams()
  const id = params.id as string
  const normalizedId = /^\d{1,2}$/.test(id) ? `bobst-${id.padStart(2, "0")}` : id
  const prensa = machineIdToPrensa(normalizedId) ?? machineIdToPrensa(id)

  const { getSolicitudesPorMaquina, getNotificacionesPorMaquina, confirmarRecepcion, crearSolicitud } = useInkStore()
  const { datos: datosTablero, connectionState, error } = useTableroHub(prensa ?? undefined)

  const tableroActual = datosTablero.find((row) => normalizePrensaCode(row.prensa) === prensa) ?? null
  const cargando = (connectionState === "Connecting" || connectionState === "Reconnecting") && datosTablero.length === 0

  const metrosRestantes = tableroActual ? parseCantidadPorUnidad(tableroActual.cantidadFaltante, "MTR") ?? 0 : 0
  const metrosTotales = tableroActual ? parseCantidadPorUnidad(tableroActual.cantidadSolicitada, "MTR") ?? 0 : 0
  const progreso = tableroActual?.porcentaje ?? 0
  const printCard = tableroActual?.printCard ?? ""
  const nombreMaquina = tableroActual ? `Prensa ${tableroActual.prensa}` : `Prensa ${prensa ?? id}`
  const estado = progreso >= 100 ? "cambio" : "activa"

  // Velocidad — el operador la ingresa una sola vez
  const [velocidad, setVelocidad] = useState("")

  // Colores cargados del Print Card
  const [filas, setFilas] = useState<FilaColor[]>([])
  const [loadingPC, setLoadingPC] = useState(false)
  const [anchoCm, setAnchoCm] = useState(0)
  const [anchoInput, setAnchoInput] = useState("")
  const [maquinaNombre, setMaquinaNombre] = useState("")
  const loadRequestRef = useRef(0)

  const solicitudesMaquina = getSolicitudesPorMaquina(normalizedId).filter(s => s.estado !== "entregado")
  const notificacionesMaquina = getNotificacionesPorMaquina(normalizedId).filter(n => !n.leida)

  const cargarColores = useCallback(async (pc: string, metros: number) => {
    if (!pc) return
    const requestId = ++loadRequestRef.current
    setLoadingPC(true)
    const data = await getPrintCard(pc)
    if (requestId !== loadRequestRef.current) return
    if (!data) {
      setFilas([])
      setLoadingPC(false)
      return
    }

    setAnchoCm(data.ancho)
    setMaquinaNombre(data.maquina)
    const kgBase = KG_BASE_MAQUINA[data.maquina] || 0

    const nuevasFilas: FilaColor[] = []
    for (let i = 0; i < data.colores.length; i++) {
      const colorNombre = data.colores[i]
      const cobertura = data.coberturas[i]
      if (!colorNombre || cobertura === 0) continue

      const tinta = await getTinta(colorNombre)
      if (requestId !== loadRequestRef.current) return
      const bcm = tinta?.bcm ?? 0
      const densidad = tinta?.densidad ?? 0
      const anilox = tinta?.anilox ?? 0

      const { kgTinta, kgDisolvente } = calcularKgPorColor(metros, data.ancho, bcm, densidad, cobertura, kgBase)

      nuevasFilas.push({
        color: colorNombre,
        tinta: tinta?.tinta ?? colorNombre,
        bcm,
        densidad,
        cobertura,
        kgTinta,
        kgDisolvente,
        anilox,
        kgEnMaquina: "",
        viscosidad: "",
        enviando: false,
      })
    }
    if (requestId !== loadRequestRef.current) return
    setFilas(nuevasFilas)
    setLoadingPC(false)
  }, [])

  useEffect(() => {
    loadRequestRef.current += 1
    setVelocidad("")
    setFilas([])
    setLoadingPC(false)
    setAnchoCm(0)
    setMaquinaNombre("")
  }, [normalizedId])

  // Cargar cuando llega el Print Card del hub
  useEffect(() => {
    if (printCard && metrosRestantes > 0) {
      void cargarColores(printCard, metrosRestantes)
      return
    }
    loadRequestRef.current += 1
    setFilas([])
    setLoadingPC(false)
    setAnchoCm(0)
    setMaquinaNombre("")
  }, [printCard, metrosRestantes, cargarColores])

  // Recalcular kg cuando cambia la velocidad (no afecta kg, solo urgencia)
  // Recalcular kg de una fila cuando se edita BCM, densidad, cobertura
  function actualizarFila(index: number, campo: keyof FilaColor, valor: string) {
    setFilas(prev => {
      const nuevas = [...prev]
      const fila = { ...nuevas[index], [campo]: valor }

      // Recalcular kg si cambian cualquier parámetro que afecta el cálculo
      if (["bcm", "densidad", "cobertura", "kgEnMaquina"].includes(campo)) {
        const bcm = campo === "bcm" ? parseFloat(valor) || 0 : parseFloat(String(fila.bcm)) || 0
        const densidad = campo === "densidad" ? parseFloat(valor) || 0 : fila.densidad
        const cobertura = campo === "cobertura" ? parseFloat(valor) || 0 : fila.cobertura
        const kgEnMaq = campo === "kgEnMaquina" ? parseFloat(valor) || 0 : parseFloat(fila.kgEnMaquina) || 0
        const kgBase = KG_BASE_MAQUINA[maquinaNombre] || 0

        const { kgTinta, kgDisolvente } = calcularKgPorColor(
          metrosRestantes, anchoCm, bcm, densidad, cobertura, kgBase, kgEnMaq
        )
        fila.kgTinta = kgTinta
        fila.kgDisolvente = kgDisolvente
      }

      nuevas[index] = fila
      return nuevas
    })
  }

  async function solicitarColor(index: number) {
    const fila = filas[index]
    if (!fila.kgEnMaquina) {
      toast.error("Ingresa los kg en máquina primero")
      return
    }
    if (!velocidad) {
      toast.error("Ingresa la velocidad actual primero")
      return
    }

    setFilas(prev => prev.map((f, i) => i === index ? { ...f, enviando: true } : f))

    const vel = parseFloat(velocidad) || 0
    const tiempoMin = calcularTiempoMinutos(metrosRestantes, vel)
    const urgencia = determinarUrgencia(tiempoMin)

    crearSolicitud({
      impresoraId: normalizedId,
      impresoraNombre: nombreMaquina,
      cuerpoNumero: index + 1,
      color: fila.color,
      serieTinta: fila.tinta,
      kgEnMaquina: parseFloat(fila.kgEnMaquina) || 0,
      metrosRestantes,
      superficiePorcentaje: fila.cobertura * 100,
      aniloxLineatura: fila.anilox,
      aniloxVolumen: fila.bcm,
      velocidadActual: vel,
      viscosidadActual: parseFloat(fila.viscosidad) || 0,
      anchoImpresion: anchoCm / 100,
      kgAFabricar: fila.kgTinta,
      tiempoEstimadoMin: tiempoMin,
      urgencia,
    })

    toast.success(`Solicitud enviada: ${fila.color}`, {
      description: `${fila.kgTinta} kg · ${tiempoMin === 999 ? "--" : tiempoMin} min`,
    })

    setFilas(prev => prev.map((f, i) => i === index ? { ...f, enviando: false } : f))
  }

  if (cargando) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="flex flex-col items-center gap-3 text-muted-foreground">
          <LoaderCircle className="h-10 w-10 animate-spin" />
          <p className="text-sm">Cargando datos de la prensa...</p>
        </div>
      </div>
    )
  }

  if (!tableroActual) {
    return (
      <div className="flex items-center justify-center py-20">
        <p className="text-muted-foreground">No hay datos para esta prensa en el hub</p>
      </div>
    )
  }

  const velNum = parseFloat(velocidad) || 0
  const tiempoMin = velNum > 0 ? calcularTiempoMinutos(metrosRestantes, velNum) : null
  const urgencia = tiempoMin !== null ? determinarUrgencia(tiempoMin) : null

  return (
    <div className="flex flex-col gap-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon" className="shrink-0">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-2xl font-bold text-foreground">{nombreMaquina}</h2>
              <Badge
                variant="outline"
                className={estado === "activa"
                  ? "bg-emerald-100 text-emerald-800 border-emerald-300"
                  : "bg-amber-100 text-amber-800 border-amber-300"}
              >
                {estado === "activa" ? "Activa" : "Cambio"}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground">
              {tableroActual.orden} · {tableroActual.producto}
            </p>
            {printCard && (
              <p className="text-xs font-mono text-muted-foreground">
                Print Card: <span className="font-bold text-foreground">{printCard}</span>
              </p>
            )}
            <p className="text-xs text-muted-foreground">
              Hub: {connectionState}{error ? ` · ${error}` : ""}
            </p>
          </div>
        </div>
      </div>

      {/* Métricas */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Progreso</CardTitle>
            <Printer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="mb-2 text-2xl font-bold font-mono text-foreground">{progreso}%</div>
            <Progress value={progreso} className="h-2" />
            <p className="mt-1 text-xs text-muted-foreground">{metrosRestantes.toLocaleString()}m restantes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Metros Totales</CardTitle>
            <Ruler className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold font-mono text-foreground">{metrosTotales.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">metros lineales</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Velocidad Actual</CardTitle>
            <Gauge className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <Input
              type="number"
              placeholder="m/min"
              value={velocidad}
              onChange={e => setVelocidad(e.target.value)}
              className="text-2xl font-bold font-mono h-10"
            />
            <p className="mt-1 text-xs text-muted-foreground">
              {tiempoMin !== null && tiempoMin !== 999
                ? <>Tiempo restante: <span className="font-medium">{tiempoMin} min</span></>
                : "ingresa para calcular urgencia"}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Urgencia</CardTitle>
            <Droplets className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent className="pt-2">
            {urgencia && tiempoMin !== null ? (
              <UrgencyBadge urgencia={urgencia} tiempoMin={tiempoMin === 999 ? undefined : tiempoMin} pulsing />
            ) : (
              <p className="text-sm text-muted-foreground">—</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Notificaciones */}
      {notificacionesMaquina.length > 0 && (
        <div>
          <h3 className="mb-3 text-lg font-semibold text-foreground">Notificaciones Activas</h3>
          <div className="flex flex-col gap-2">
            {notificacionesMaquina.map(n => (
              <div key={n.id} className="flex items-center gap-2">
                <div className="flex-1">
                  <FlashingAlert tipo={n.tipo} mensaje={n.mensaje} timestamp={n.timestamp} leida={n.leida} />
                </div>
                {n.tipo === "fabricado" && (
                  <Button size="sm" onClick={() => confirmarRecepcion(n.solicitudId)}>Confirmar</Button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Solicitudes activas */}
      {solicitudesMaquina.length > 0 && (
        <div>
          <h3 className="mb-3 text-lg font-semibold text-foreground">Solicitudes Activas</h3>
          <div className="flex flex-col gap-2">
            {solicitudesMaquina.map(s => (
              <Card key={s.id} className="p-4">
                <div className="flex flex-wrap items-center gap-4">
                  <div>
                    <p className="text-sm font-semibold text-foreground">{s.id} · Cuerpo {s.cuerpoNumero}</p>
                    <p className="text-xs text-muted-foreground">{s.color}</p>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Kg: </span>
                    <span className="font-mono font-semibold">{s.kgAFabricar}</span>
                  </div>
                  <UrgencyBadge urgencia={s.urgencia} tiempoMin={s.tiempoEstimadoMin} />
                  <StatusBadge estado={s.estado} />
                  {s.estado === "fabricado" && (
                    <Button size="sm" onClick={() => confirmarRecepcion(s.id)}>Confirmar Recepción</Button>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Cuerpos Impresores */}
      <div>
        <h3 className="mb-3 text-lg font-semibold text-foreground">Cuerpos Impresores</h3>
        <Card>
          {loadingPC ? (
            <CardContent className="py-10 flex items-center justify-center gap-3 text-muted-foreground">
              <LoaderCircle className="h-5 w-5 animate-spin" />
              <span className="text-sm">Cargando colores del Print Card...</span>
            </CardContent>
          ) : filas.length === 0 ? (
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              {printCard
                ? `No se encontraron colores para ${printCard}`
                : "Sin Print Card asignado a esta orden"}
            </CardContent>
          ) : (
            <div className="overflow-x-auto">
              {anchoCm === 0 && (
                <div className="flex items-center gap-3 px-4 py-3 border-b bg-amber-50 dark:bg-amber-950/30">
                  <span className="text-sm text-amber-700 dark:text-amber-400">
                    Ancho no disponible en el Print Card — ingrésalo para calcular kg:
                  </span>
                  <Input
                    type="number"
                    placeholder="cm"
                    className="w-24 h-8 text-sm font-mono"
                    value={anchoInput}
                    onChange={e => setAnchoInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        const val = parseFloat(anchoInput) || 0
                        if (!val) return
                        setAnchoCm(val)
                        const kgBase = KG_BASE_MAQUINA[maquinaNombre] || 0
                        setFilas(prev => prev.map(f => {
                          if (!f.bcm || !f.densidad) return f
                          const { kgTinta, kgDisolvente } = calcularKgPorColor(
                            metrosRestantes, val, f.bcm, f.densidad, f.cobertura, kgBase
                          )
                          return { ...f, kgTinta, kgDisolvente }
                        }))
                      }
                    }}
                  />
                  <span className="text-sm text-muted-foreground">cm</span>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      const val = parseFloat(anchoInput) || 0
                      if (!val) return
                      setAnchoCm(val)
                      const kgBase = KG_BASE_MAQUINA[maquinaNombre] || 0
                      setFilas(prev => prev.map(f => {
                        if (!f.bcm || !f.densidad) return f
                        const { kgTinta, kgDisolvente } = calcularKgPorColor(
                          metrosRestantes, val, f.bcm, f.densidad, f.cobertura, kgBase
                        )
                        return { ...f, kgTinta, kgDisolvente }
                      }))
                    }}
                  >
                    Calcular
                  </Button>
                </div>
              )}
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-muted-foreground">
                    <th className="px-4 py-3 text-left font-medium">#</th>
                    <th className="px-4 py-3 text-left font-medium">Color</th>
                    <th className="px-4 py-3 text-right font-medium">Anilox (LPI)</th>
                    <th className="px-4 py-3 text-right font-medium">BCM (cm³/m²)</th>
                    <th className="px-4 py-3 text-right font-medium">Cob. %</th>
                    <th className="px-4 py-3 text-right font-medium">Kg calculados</th>
                    <th className="px-4 py-3 text-right font-medium">Kg en máquina</th>
                    <th className="px-4 py-3 text-right font-medium">Viscosidad</th>
                    <th className="px-4 py-3 text-right font-medium">Acción</th>
                  </tr>
                </thead>
                <tbody>
                  {filas.map((fila, i) => (
                    <tr key={i} className="border-b last:border-0 hover:bg-muted/30">
                      <td className="px-4 py-3 font-mono font-bold text-foreground">{i + 1}</td>
                      <td className="px-4 py-3">
                        <div className="font-medium text-foreground">{fila.color}</div>
                        <div className="text-xs text-muted-foreground">{fila.tinta}</div>
                      </td>
                      {/* Anilox editable */}
                      <td className="px-4 py-3 text-right">
                        <Input
                          type="number"
                          value={fila.anilox || ""}
                          onChange={e => actualizarFila(i, "anilox", e.target.value)}
                          className="w-20 text-right font-mono text-sm h-8 ml-auto"
                          placeholder="LPI"
                        />
                      </td>
                      {/* BCM editable */}
                      <td className="px-4 py-3 text-right">
                        <Input
                          type="number"
                          step="0.1"
                          value={fila.bcm || ""}
                          onChange={e => actualizarFila(i, "bcm", e.target.value)}
                          className="w-20 text-right font-mono text-sm h-8 ml-auto"
                          placeholder="BCM"
                        />
                      </td>
                      {/* Cobertura editable */}
                      <td className="px-4 py-3 text-right">
                        <Input
                          type="number"
                          step="0.1"
                          value={fila.cobertura ? (fila.cobertura * 100).toFixed(1) : ""}
                          onChange={e => actualizarFila(i, "cobertura", String(parseFloat(e.target.value) / 100 || 0))}
                          className="w-20 text-right font-mono text-sm h-8 ml-auto"
                          placeholder="%"
                        />
                      </td>
                      {/* Kg calculados */}
                      <td className="px-4 py-3 text-right">
                        {fila.kgTinta > 0 ? (
                          <span className="font-mono font-bold text-foreground">{fila.kgTinta} kg</span>
                        ) : (!fila.bcm || !fila.densidad) ? (
                          <span className="text-xs text-amber-600 dark:text-amber-400" title="Ingresa BCM y densidad para calcular">
                            Falta BCM/densidad
                          </span>
                        ) : (
                          <span className="font-mono font-bold text-muted-foreground">—</span>
                        )}
                      </td>
                      {/* Kg en máquina — operador */}
                      <td className="px-4 py-3 text-right">
                        <Input
                          type="number"
                          step="0.1"
                          value={fila.kgEnMaquina}
                          onChange={e => actualizarFila(i, "kgEnMaquina", e.target.value)}
                          className="w-20 text-right font-mono text-sm h-8 ml-auto"
                          placeholder="kg"
                        />
                      </td>
                      {/* Viscosidad — operador */}
                      <td className="px-4 py-3 text-right">
                        <Input
                          type="number"
                          value={fila.viscosidad}
                          onChange={e => actualizarFila(i, "viscosidad", e.target.value)}
                          className="w-20 text-right font-mono text-sm h-8 ml-auto"
                          placeholder="seg"
                        />
                      </td>
                      {/* Solicitar */}
                      <td className="px-4 py-3 text-right">
                        <Button
                          size="sm"
                          onClick={() => solicitarColor(i)}
                          disabled={fila.enviando || !fila.kgEnMaquina || !velocidad}
                        >
                          {fila.enviando
                            ? <LoaderCircle className="h-3 w-3 animate-spin" />
                            : <><Send className="mr-1 h-3 w-3" />Solicitar</>}
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}
