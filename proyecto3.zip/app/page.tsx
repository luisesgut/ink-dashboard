"use client"

import { useMemo } from "react"
import { PrinterCard } from "@/components/printer-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useTableroHub } from "@/lib/tablero-hub"
import { tintasToImpresoras } from "@/lib/tablero-mappers"
import {
  LoaderCircle,
  Printer,
  AlertTriangle,
  FlaskConical,
  Clock,
} from "lucide-react"

export default function DashboardPage() {
  const { datos: datosTablero, connectionState, error } = useTableroHub()

  const impresorasHub = useMemo(() => tintasToImpresoras(datosTablero), [datosTablero])
  const cargandoHub =
    (connectionState === "Connecting" || connectionState === "Reconnecting") &&
    impresorasHub.length === 0

  const maquinasActivas = impresorasHub.filter((i) => i.estado === "activa").length
  const solicitudesPendientes = datosTablero.length
  const solicitudesUrgentes = datosTablero.filter((s) => s.porcentaje >= 80 && s.porcentaje < 100).length
  const enFabricacion = datosTablero.filter((s) => s.porcentaje > 0 && s.porcentaje < 100).length

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-foreground text-balance">
          Panel de Control
        </h2>
        <p className="text-sm text-muted-foreground">
          Estado en tiempo real de las impresoras y solicitudes de tinta
        </p>
        <p className="mt-1 text-xs text-muted-foreground">
          Fuente: tableroImpresionHub ({connectionState})
          {error ? ` - ${error}` : ""}
        </p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Maquinas Activas
            </CardTitle>
            <Printer className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{maquinasActivas}</div>
            <p className="text-xs text-muted-foreground">de {impresorasHub.length} totales</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Solicitudes Pendientes
            </CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{solicitudesPendientes}</div>
            <p className="text-xs text-muted-foreground">esperando fabricacion</p>
          </CardContent>
        </Card>

        <Card className="border-urgency-red/30">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-urgency-red">
              Urgentes
            </CardTitle>
            <AlertTriangle className="h-4 w-4 text-urgency-red" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-urgency-red font-mono">{solicitudesUrgentes}</div>
            <p className="text-xs text-muted-foreground">{"menos de 30 min"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              En Fabricacion
            </CardTitle>
            <FlaskConical className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground font-mono">{enFabricacion}</div>
            <p className="text-xs text-muted-foreground">tinta en proceso</p>
          </CardContent>
        </Card>
      </div>

      {/* Printer Grid */}
      <div>
        <h3 className="mb-4 text-lg font-semibold text-foreground">
          Impresoras
        </h3>
        {cargandoHub ? (
          <Card>
            <CardContent className="flex min-h-40 flex-col items-center justify-center gap-3 text-muted-foreground">
              <LoaderCircle className="h-10 w-10 animate-spin" />
              <p className="text-sm">Conectando al hub de órdenes...</p>
            </CardContent>
          </Card>
        ) : impresorasHub.length === 0 ? (
          <Card>
            <CardContent className="flex min-h-40 flex-col items-center justify-center gap-2 text-muted-foreground">
              <Printer className="h-10 w-10 opacity-40" />
              <p className="text-sm font-medium">Sin datos del hub</p>
              <p className="text-xs">No se recibieron máquinas desde `172.16.10.31`.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {impresorasHub.map((impresora) => (
              <PrinterCard key={impresora.id} impresora={impresora} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
