// lib/pocketbase.ts
const PB_URL = process.env.NEXT_PUBLIC_POCKETBASE_URL || "http://127.0.0.1:8090"

export interface PrintCardData {
  print_card: string
  producto: string
  ancho: number
  maquina: string
  colores: string[]
  coberturas: number[]
}

export interface TintaData {
  pantone: string
  tinta: string
  anilox: number
  bcm: number
  densidad: number
  precio: number
}

export interface KgPorColor {
  color: string      // nombre original del Print Card (ej: "CYAN")
  tinta: string      // nombre de la tinta base (ej: "Cyan")
  bcm: number        // cm3/m2 — editable por operador
  densidad: number   // editable por operador
  cobertura: number  // decimal (0.56 = 56%) — editable
  kgTinta: number    // calculado
  kgDisolvente: number
  anilox: number     // LPI — editable
}

export const TRANSFERENCIA = 0.3
export const DILUCION = 0.1

export async function getPrintCard(printCard: string): Promise<PrintCardData | null> {
  try {
    const encoded = encodeURIComponent(printCard.trim())
    const res = await fetch(
      `${PB_URL}/api/collections/print_cards/records?filter=(print_card='${encoded}')&perPage=1`
    )
    if (!res.ok) return null
    const data = await res.json()
    if (!data.items?.length) return null

    const r = data.items[0]
    const colores = [
      r.color_1, r.color_2, r.color_3, r.color_4, r.color_5,
      r.color_6, r.color_7, r.color_8, r.color_9, r.color_10
    ].filter(Boolean)

    const coberturas = [
      r.cob_1, r.cob_2, r.cob_3, r.cob_4, r.cob_5,
      r.cob_6, r.cob_7, r.cob_8, r.cob_9, r.cob_10
    ].slice(0, colores.length).map(c => parseFloat(c) || 0)

    return {
      print_card: r.print_card,
      producto: r.producto,
      ancho: parseFloat(r.ancho) || 0,
      maquina: r.maquina || "",
      colores,
      coberturas,
    }
  } catch (e) {
    console.error("Error fetching print card:", e)
    return null
  }
}

export async function getTinta(nombre: string): Promise<TintaData | null> {
  try {
    const encoded = encodeURIComponent(nombre.trim())
    const res = await fetch(
      `${PB_URL}/api/collections/tintas/records?filter=(pantone~'${encoded}'||tinta~'${encoded}')&perPage=1`
    )
    if (!res.ok) return null
    const data = await res.json()
    if (!data.items?.length) return null

    const item = data.items[0]
    // Forzar conversión a número — vienen como string del Excel
    return {
      ...item,
      anilox: parseFloat(item.anilox) || 0,
      bcm: parseFloat(item.bcm) || 0,
      densidad: parseFloat(item.densidad) || 0,
      precio: parseFloat(item.precio) || 0,
    } as TintaData
  } catch (e) {
    console.error("Error fetching tinta:", e)
    return null
  }
}

export function calcularKgPorColor(
  metros: number,
  anchoCm: number,
  bcm: number,
  densidad: number,
  cobertura: number,
  kgBase: number = 0,
  kgEnMaquina: number = 0  // ← agregar este parámetro
): { kgTinta: number; kgDisolvente: number } {
  if (!bcm || !densidad) return { kgTinta: 0, kgDisolvente: 0 }
  const m2 = metros * anchoCm / 100
  const pctTinta = 1 / (1 + DILUCION)
  const pctDisolvente = DILUCION / (1 + DILUCION)
  const base = (m2 * bcm * densidad / 1000) * cobertura * TRANSFERENCIA
  const kgTinta = Math.max(0, base * pctTinta + kgBase - kgEnMaquina)  // ← restar kgEnMaquina
  const kgDisolvente = base * pctDisolvente
  return {
    kgTinta: Math.round(kgTinta * 100) / 100,
    kgDisolvente: Math.round(kgDisolvente * 100) / 100,
  }
}