"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import {
  type SolicitudTinta,
  type Notificacion,
  type Impresora,
  type RegistroHistorial,
  type NivelUrgencia,
} from "./mock-data"

interface InkStore {
  solicitudes: SolicitudTinta[]
  notificaciones: Notificacion[]
  impresoras: Impresora[]
  historial: RegistroHistorial[]
  // Acciones operador
  crearSolicitud: (sol: Omit<SolicitudTinta, "id" | "timestamp" | "estado">) => void
  // Acciones tintero
  marcarFabricando: (solId: string) => void
  marcarFabricado: (solId: string, kgReales: number) => void
  // Acciones operador (recepcion)
  confirmarRecepcion: (solId: string) => void
  // Notificaciones
  marcarNotificacionLeida: (notId: string) => void
  marcarTodasLeidas: () => void
  // Derived
  getSolicitudesPorMaquina: (maquinaId: string) => SolicitudTinta[]
  getNotificacionesPorMaquina: (maquinaId: string) => Notificacion[]
  getNotificacionesSinLeer: () => number
}

const InkContext = createContext<InkStore | null>(null)

let nextSolId = 100
let nextNotId = 100

export function InkProvider({ children }: { children: ReactNode }) {
  const [solicitudes, setSolicitudes] = useState<SolicitudTinta[]>([])
  const [notificaciones, setNotificaciones] = useState<Notificacion[]>([])
  const [impresoras, setImpresoras] = useState<Impresora[]>([])
  const [historial, setHistorial] = useState<RegistroHistorial[]>([])

  const crearSolicitud = useCallback(
    (sol: Omit<SolicitudTinta, "id" | "timestamp" | "estado">) => {
      nextSolId++
      const newSol: SolicitudTinta = {
        ...sol,
        id: `SOL-${String(nextSolId).padStart(3, "0")}`,
        timestamp: new Date(),
        estado: "pendiente",
      }
      setSolicitudes((prev) => [newSol, ...prev])

      // Update impresora pending count
      setImpresoras((prev) =>
        prev.map((imp) =>
          imp.id === sol.impresoraId
            ? { ...imp, solicitudesPendientes: imp.solicitudesPendientes + 1 }
            : imp
        )
      )
    },
    []
  )

  const marcarFabricando = useCallback(
    (solId: string) => {
      let targetSol: SolicitudTinta | undefined
      setSolicitudes((prev) =>
        prev.map((s) => {
          if (s.id === solId) {
            targetSol = s
            return { ...s, estado: "fabricando" as const, timestampFabricando: new Date() }
          }
          return s
        })
      )

      // Create notification for the machine operator
      setTimeout(() => {
        if (targetSol) {
          nextNotId++
          const newNot: Notificacion = {
            id: `NOT-${String(nextNotId).padStart(3, "0")}`,
            impresoraId: targetSol.impresoraId,
            impresoraNombre: targetSol.impresoraNombre,
            solicitudId: targetSol.id,
            color: targetSol.color,
            tipo: "fabricando",
            mensaje: `Su tinta ${targetSol.color} se esta fabricando`,
            timestamp: new Date(),
            leida: false,
          }
          setNotificaciones((prev) => [newNot, ...prev])
          setImpresoras((prev) =>
            prev.map((imp) =>
              imp.id === targetSol!.impresoraId
                ? { ...imp, tieneNotificacion: true }
                : imp
            )
          )
        }
      }, 0)
    },
    []
  )

  const marcarFabricado = useCallback(
    (solId: string, kgReales: number) => {
      let targetSol: SolicitudTinta | undefined
      setSolicitudes((prev) =>
        prev.map((s) => {
          if (s.id === solId) {
            targetSol = { ...s }
            return {
              ...s,
              estado: "fabricado" as const,
              kgFabricados: kgReales,
              timestampFabricado: new Date(),
            }
          }
          return s
        })
      )

      setTimeout(() => {
        if (targetSol) {
          nextNotId++
          const newNot: Notificacion = {
            id: `NOT-${String(nextNotId).padStart(3, "0")}`,
            impresoraId: targetSol.impresoraId,
            impresoraNombre: targetSol.impresoraNombre,
            solicitudId: targetSol.id,
            color: targetSol.color,
            tipo: "fabricado",
            mensaje: `Tinta ${targetSol.color} lista - ${kgReales} kg - Confirmar recepcion`,
            timestamp: new Date(),
            leida: false,
          }
          setNotificaciones((prev) => [newNot, ...prev])
          setImpresoras((prev) =>
            prev.map((imp) =>
              imp.id === targetSol!.impresoraId
                ? { ...imp, tieneNotificacion: true }
                : imp
            )
          )
        }
      }, 0)
    },
    []
  )

  const confirmarRecepcion = useCallback(
    (solId: string) => {
      let targetSol: SolicitudTinta | undefined
      setSolicitudes((prev) =>
        prev.map((s) => {
          if (s.id === solId) {
            targetSol = s
            return { ...s, estado: "entregado" as const, timestampEntregado: new Date() }
          }
          return s
        })
      )

      // Mark related notifications as read
      setNotificaciones((prev) =>
        prev.map((n) => (n.solicitudId === solId ? { ...n, leida: true } : n))
      )

      // Add to history
      setTimeout(() => {
        if (targetSol) {
          const reg: RegistroHistorial = {
            id: `HIS-${Date.now()}`,
            fechaSolicitud: targetSol.timestamp,
            fechaCompletado: new Date(),
            impresoraNombre: targetSol.impresoraNombre,
            color: targetSol.color,
            serieTinta: targetSol.serieTinta,
            kgSolicitados: targetSol.kgAFabricar,
            kgFabricados: targetSol.kgFabricados || targetSol.kgAFabricar,
            tiempoUrgenciaOriginal: targetSol.tiempoEstimadoMin,
            tiempoRealFabricacion: targetSol.timestampFabricado
              ? Math.round(
                  (targetSol.timestampFabricado.getTime() -
                    (targetSol.timestampFabricando?.getTime() || targetSol.timestamp.getTime())) /
                    60000
                )
              : 0,
            estado:
              (targetSol.kgFabricados || 0) > targetSol.kgAFabricar + 0.5
                ? "retorno_parcial"
                : "completado",
          }
          setHistorial((prev) => [reg, ...prev])

          // Update impresora
          setImpresoras((prev) =>
            prev.map((imp) => {
              if (imp.id !== targetSol!.impresoraId) return imp
              const pendingCount = Math.max(0, imp.solicitudesPendientes - 1)
              // Check if there are still unread notifications for this machine
              return { ...imp, solicitudesPendientes: pendingCount }
            })
          )
        }
      }, 0)
    },
    []
  )

  const marcarNotificacionLeida = useCallback((notId: string) => {
    setNotificaciones((prev) =>
      prev.map((n) => (n.id === notId ? { ...n, leida: true } : n))
    )
  }, [])

  const marcarTodasLeidas = useCallback(() => {
    setNotificaciones((prev) => prev.map((n) => ({ ...n, leida: true })))
    setImpresoras((prev) => prev.map((imp) => ({ ...imp, tieneNotificacion: false })))
  }, [])

  const getSolicitudesPorMaquina = useCallback(
    (maquinaId: string) => solicitudes.filter((s) => s.impresoraId === maquinaId),
    [solicitudes]
  )

  const getNotificacionesPorMaquina = useCallback(
    (maquinaId: string) => notificaciones.filter((n) => n.impresoraId === maquinaId),
    [notificaciones]
  )

  const getNotificacionesSinLeer = useCallback(
    () => notificaciones.filter((n) => !n.leida).length,
    [notificaciones]
  )

  return (
    <InkContext.Provider
      value={{
        solicitudes,
        notificaciones,
        impresoras,
        historial,
        crearSolicitud,
        marcarFabricando,
        marcarFabricado,
        confirmarRecepcion,
        marcarNotificacionLeida,
        marcarTodasLeidas,
        getSolicitudesPorMaquina,
        getNotificacionesPorMaquina,
        getNotificacionesSinLeer,
      }}
    >
      {children}
    </InkContext.Provider>
  )
}

export function useInkStore() {
  const ctx = useContext(InkContext)
  if (!ctx) throw new Error("useInkStore must be used within InkProvider")
  return ctx
}
